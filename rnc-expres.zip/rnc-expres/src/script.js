document.addEventListener('DOMContentLoaded', () => {
    const addEmprendimientoButton = document.getElementById('addEmprendimiento');
    const emprendimientoForm = document.getElementById('emprendimientoForm');

    addEmprendimientoButton.addEventListener('click', () => {
        emprendimientoForm.style.display = 'flex';
    });

    emprendimientoForm.addEventListener('submit', (event) => {
        event.preventDefault();
        const nombre = document.getElementById('nombreEmprendimiento').value;
        const descripcion = document.getElementById('descripcionEmprendimiento').value;
        const imagenes = document.getElementById('imagenesEmprendimiento').files;

        const formData = new FormData();
        formData.append('nombre', nombre);
        formData.append('descripcion', descripcion);
        for (let i = 0; i < imagenes.length; i++) {
            formData.append('imagenes', imagenes[i]);
        }

        // Simulación de envío de datos
        console.log('Datos del emprendimiento:', nombre, descripcion, imagenes);
        alert('Emprendimiento agregado exitosamente');
        emprendimientoForm.reset();
        emprendimientoForm.style.display = 'none';
        fetchEmprendimientos(); // Actualizar la lista de emprendimientos
    });

    function fetchEmprendimientos() {
        // Simulación de obtención de datos
        const emprendimientos = [
            { nombre: 'Emprendimiento 1', descripcion: 'Descripción 1' },
            { nombre: 'Emprendimiento 2', descripcion: 'Descripción 2' }
        ];
        displayEmprendimientos(emprendimientos);
    }

    function displayEmprendimientos(emprendimientos) {
        const container = document.getElementById('emprendimientosContainer');
        container.innerHTML = ''; // Limpiar el contenido existente
        emprendimientos.forEach(emprendimiento => {
            const div = document.createElement('div');
            div.classList.add('emprendimiento');
            div.innerHTML = `<h3>${emprendimiento.nombre}</h3><p>${emprendimiento.descripcion}</p>`;
            container.appendChild(div);
        });
    }

    // Llamar a fetchEmprendimientos al cargar la página
    fetchEmprendimientos();
});
